# -*- coding: utf-8 -*-
"""
Created on Mon Oct  2 14:40:12 2023

@author: 10449
"""

import pandas as pd
import os
from pathlib import Path
os.chdir('D:\Msc\BigDataMediaTech\Project\Data')

# In[]

for file in os.listdir('Air/'):
    
    path = Path('Air/' + file)
   
    if(path.is_file()): 
        
        print(file)
        
        df = pd.read_csv('Air/' + file, low_memory=False)

        res = pd.DataFrame(columns=['Route','AP1','AP2','Time','Pas_Arr','Pas_Dep'])
              
        temp = df[['tra_meas','airp_pr','TIME_PERIOD','OBS_VALUE']]
        temp = temp.groupby(['airp_pr', 'TIME_PERIOD', 'tra_meas', ])['OBS_VALUE'].sum().reset_index()
        
        i = 0
        while i < len(temp)-2:
                    
            tar1 = temp.iloc[i]
            tar2 = temp.iloc[i+1]
                    
            if tar1['airp_pr'] == tar2['airp_pr']:
                row = {'Route':tar1['tra_meas'], 'AP1':tar1['airp_pr'][:7], 'AP2':tar1['airp_pr'][8:], 
                       'Time':tar1['TIME_PERIOD'], 'Pas_Arr':tar1['OBS_VALUE'], 'Pas_Dep':tar2['OBS_VALUE']}
                           
                row_df = pd.DataFrame([row])
                res = pd.concat([res, row_df])         
                
                i += 2
            
            else:
                i += 1
        
        res.to_csv('Air/CSV/' + file[15:17] + '.csv')