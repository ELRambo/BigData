#!/usr/bin/env python
# coding: utf-8

# In[4]:


import pandas as pd
import numpy as np
import re
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn import svm
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.metrics import accuracy_score, classification_report

# Load the training, test, and evaluation datasets
train_df = pd.read_csv('train.csv')
test_df = pd.read_csv('test.csv')

train_df['tou_net'] = train_df['tou_net'].fillna("")
test_df['tou_net'] = test_df['tou_net'].fillna("")
train_df.tou_net = train_df.tou_net.astype(str)
test_df.tou_net = test_df.tou_net.astype(str)

train_df.fillna(0,inplace=True)
test_df.fillna(0,inplace=True)

# Feature extraction using TF-IDF vectorization
vectorizer = TfidfVectorizer(max_features=1000)
X_train = vectorizer.fit_transform(train_df['tou_net'])
X_test = vectorizer.transform(test_df['tou_net'])

# Define target labels
y_train = train_df['net_imp']
y_test = test_df['net_imp']


# Train a Multinomial Naïve Bayes classifier
clf = svm.SVC(kernel='linear')
clf.fit(X_train, y_train)

# Evaluate the classifier on the test dataset
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
classification_rep = classification_report(y_test, y_pred)

# 评估模型
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)


print(f"均方误差 (MSE): {mse}")
print(f"决定系数 (R^2): {r2}")

# Print the results
print(f"Accuracy: {accuracy}")


# In[6]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error,  r2_score

# 读取数据
data = pd.read_csv('DATA_0.csv')

# 分离特征和目标变量
X = data['tou_net']
y = data['net_imp']

# 将数据分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

X_train = X_train.values.reshape(-1, 1)
X_test = X_test.values.reshape(-1, 1)

# 创建SVM回归模型
svm_model = SVR(kernel='linear', C=1.0, epsilon=0.2)

# 训练模型
svm_model.fit(X_train, y_train)

# 预测销量
y_pred = svm_model.predict(X_test)

# 评估模型性能（使用均方误差MSE作为指标）
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"均方误差(MSE): {mse}")
print(f"决定系数 (R^2): {r2}")

# 如果需要，您还可以可视化实际值与预测值的比较
import matplotlib.pyplot as plt
plt.scatter(y_test, y_pred)
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Actual vs. Predicted Values")
plt.show()


# In[ ]:




