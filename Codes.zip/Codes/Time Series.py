#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd

# 读取时间序列数据
data = pd.read_csv('DATA_0.csv', parse_dates=['time'])
data.set_index('time', inplace=True)

# 可视化数据
import matplotlib.pyplot as plt
data.plot()
plt.show()



# In[2]:


pip install numpy==1.23.5


# In[10]:


import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score

# 1. 准备数据
# 假设您有一个名为'data'的时间序列数据
data = pd.read_csv('DATA_0.csv', usecols=['time', 'net_imp'])
data['time'] = pd.to_datetime(data['time'])
data.set_index('time', inplace=True)
data = data.reshape(-1, 1)  # 重新塑造数据以适应Scaler

# 将数据缩放到0到1之间
scaler = MinMaxScaler(feature_range=(-3, 7))
data = scaler.fit_transform(data)

# 分割数据集为训练集和测试集
train_size = int(len(data) * 0.8)
train_data, test_data = data[:train_size], data[train_size:]

#print(test_data)
# 2. 创建模型
model = Sequential()
model.add(LSTM(50, activation='relu', input_shape=(1, 1)))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mean_squared_error')

# 3. 训练模型
X_train, y_train = [], []
for i in range(1, len(train_data)):
    X_train.append(train_data[i-1:i])
    y_train.append(train_data[i])

X_train, y_train = np.array(X_train), np.array(y_train)
model.fit(X_train, y_train, epochs=50, batch_size=1)

# 4. 做出预测
X_test, y_test = [], []
for i in range(1, len(test_data)):
    X_test.append(test_data[i-1:i])
    y_test.append(test_data[i])

X_test, y_test = np.array(X_test), np.array(y_test)
predictions = model.predict(X_test)
predictions = scaler.inverse_transform(predictions)  # 反向缩放

# 评估模型的准确率
mse = mean_squared_error(y_test, predictions)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, predictions)
print(f"决定系数 (R^2): {r2}")
print(f"均方误差 (MSE): {mse}")
print(f"均方根误差 (RMSE): {rmse}")

# 5. 可视化预测结果
plt.plot(y_test, label='Actual')
plt.plot(predictions, label='Predicted')
plt.legend()
plt.show()

plt.scatter(y_test, predictions)
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Actual vs. Predicted Values")
plt.show()


# In[4]:


import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.holtwinters import ExponentialSmoothing

# 读取时间序列数据，假设数据具有日期时间索引
data = pd.read_csv('train.csv', parse_dates=['time'])
data.set_index('time', inplace=True)

endog = data['net_imp']

# 创建Holt-Winters模型
model = ExponentialSmoothing(endog, trend='add', seasonal='add', seasonal_periods=12)

# 拟合模型
model_fit = model.fit()

# 进行预测
forecast = model_fit.forecast(steps=12)

# 可视化原始数据和预测
plt.plot(data, label='Original Data')
plt.plot(forecast, label='Forecast', color='red')
plt.legend()
plt.show()


# In[15]:


import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import LSTM, Dense
import matplotlib.pyplot as plt

# 读取时间序列数据
data = pd.read_csv('DATA_0.csv', usecols=['time', 'net_imp'])
data['time'] = pd.to_datetime(data['time'])
data.set_index('time', inplace=True)

# 数据预处理
scaler = MinMaxScaler()
data['net_imp'] = scaler.fit_transform(data['net_imp'].values.reshape(-1, 1))

# 创建训练集和测试集
train_size = int(len(data) * 0.8)
train_data, test_data = data.iloc[:train_size], data.iloc[train_size:]

# 准备训练数据
def create_dataset(dataset, time_step=1):
    X, y = [], []
    for i in range(len(dataset) - time_step):
        X.append(dataset[i:i+time_step])
        y.append(dataset[i+time_step])
    return np.array(X), np.array(y)

time_steps = 10  # 时间步长，您可以根据数据的特点进行调整
X_train, y_train = create_dataset(train_data['net_imp'].values, time_steps)
X_test, y_test = create_dataset(test_data['net_imp'].values, time_steps)

# 构建LSTM模型
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape=(time_steps, 1)))
model.add(LSTM(50, return_sequences=True))
model.add(LSTM(50))
model.add(Dense(1))

# 编译模型
model.compile(loss='mean_squared_error', optimizer='adam')

# 训练模型
model.fit(X_train, y_train, epochs=100, batch_size=64)

# 在测试集上进行预测
y_pred = model.predict(X_test)

# 反向缩放预测值
y_pred = scaler.inverse_transform(y_pred)
y_test = y_test.reshape(-1, 1)  # 重新塑造数据以适应Scaler
y_test = scaler.inverse_transform(y_test)

# 可视化真实值与预测值
plt.plot(test_data.index[time_steps:], test_data['net_imp'].values[time_steps:], label='True Values')
plt.plot(test_data.index[time_steps:], y_pred, label='Predicted Values')
plt.legend()
plt.show()

# 评估模型的准确率
mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, y_pred)
print(f"决定系数 (R^2): {r2}")
print(f"均方误差 (MSE): {mse}")
print(f"均方根误差 (RMSE): {rmse}")

# 5. 可视化预测结果
plt.scatter(y_test, y_pred)
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Actual vs. Predicted Values")
plt.show()


# In[ ]:




