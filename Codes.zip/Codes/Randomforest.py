#!/usr/bin/env python
# coding: utf-8

# In[1]:


pip install numpy==1.23.5


# In[4]:


# 导入所需的库
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

# 假设您有一个包含特征的X和目标变量的y的数据集
# X是特征矩阵，y是目标向量
# 读取数据集
data = pd.read_csv('forest.csv')
data['tou_net'] = data['tou_net'].fillna("")
data.tou_net = data.tou_net.astype(str)
X = data.drop('tou_net', axis=1)
y = data['net_imp']

# 将数据集分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 创建随机森林回归模型
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)

# 训练模型
rf_model.fit(X_train, y_train)

# 使用模型进行预测
y_pred = rf_model.predict(X_test)

# 评估模型
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Mean Squared Error (MSE): {mse}")
print(f"R-squared (R2) Score: {r2}")

# 如果需要，您还可以可视化实际值与预测值的比较
import matplotlib.pyplot as plt

plt.scatter(y_test, y_pred)
plt.xlabel("Actual Values")
plt.ylabel("Predicted Values")
plt.title("Actual vs. Predicted Values")
plt.show()


# In[ ]:




