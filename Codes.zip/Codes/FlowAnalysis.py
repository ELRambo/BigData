# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 17:52:16 2023

@author: 10449
"""

import pandas as pd
import os
import geopandas as gpd

os.chdir('D:\Msc\BigDataMediaTech\Project\Data')

# In[flow]

cli = ['AT','CZ','DE','EL','ES','FR','HR','IT','NL','PT','UK']
result = pd.DataFrame(index=cli)

for i in range(0, 11):
    
    # print(cli[i])
    
    df = pd.read_csv('Air/Selected/' + cli[i] + '.csv')
    
    gdf = gpd.read_file('SHP/FLow/' + cli[i] + '.shp')
    gdf.set_index('Abbr', inplace=True)
    
    # calculate the number of passengers arrived in country cli[i] from every other country in 2019
    df = df[(df['AP2'].str[:2].isin(cli)) & (df['AP2'].str[:2] != cli[i])]
    df = df[df['Time'].str[:4]=='2019']    
    grouped_df = df.groupby(df['AP2'].str[:2])['Pas_Arr'].sum().reset_index()
    grouped_df.set_index('AP2', inplace=True)
    
    # connect flow values to shapefiles
    gdf = gdf.combine_first(grouped_df)
    gdf.to_file('SHP/FLow/Pas/' + cli[i] + '_flow.shp')
    
    result = result.combine_first(grouped_df)
    result.rename(columns={'Pas_Arr':cli[i]}, inplace=True)

result.to_csv('Air/Selected/flow.csv')

# In[contribution]

trade = pd.read_csv('Wine/Trade_sel.csv')
trade['reporter'] = trade['reporter'].replace({'GB':'UK', 'GR':'EL'})
trade['partner'] = trade['partner'].replace({'GB':'UK', 'GR':'EL'})

flow = pd.read_csv('Air/Selected/flow.csv')
flow.set_index('Unnamed: 0', inplace=True)

grouped_trade = trade.groupby(['reporter', 'partner'])['OBS_VALUE'].sum().reset_index()
grouped_trade.set_index('partner', inplace=True)

for i in range(0, 11):
    
    print(cli[i])
    
    temp = grouped_trade[grouped_trade['reporter']==cli[i]]
    cli = ['AT','CZ','DE','EL','ES','FR','HR','IT','NL','PT','UK']
    net = pd.DataFrame(index=cli)
    
    gdf = gpd.read_file('SHP/FLow/Pas/' + cli[i] + '_flow.shp')
    gdf.set_index('index', inplace=True)
    
    net = net.combine_first(grouped_trade[grouped_trade['reporter']==cli[i]]).combine_first(flow[[cli[i]]])
    net.rename(columns={'OBS_VALUE':'Trade', cli[i]:'Pas_Arr'}, inplace=True)
    net['contri'] = net['Trade'] / net['Pas_Arr']
    net['contri'] = net['contri'].round(1)
    gdf = gdf.combine_first(net)
    gdf.to_file('SHP/FLow/Pas/' + cli[i] + '_flow.shp')
    
# In[]

cli = ['AT','CZ','DE','EL','ES','FR','HR','IT','NL','PT','UK']
result = pd.DataFrame(index=cli)

for i in range(0, 11):
    
    # print(cli[i])
        
    gdf = gpd.read_file('SHP/FLow/Pas/' + cli[i] + '_flow.shp')
    gdf.set_index('index', inplace=True)
        
    # get contribution table    
    result = result.combine_first(gdf[['contri']])
    result.rename(columns={'contri':cli[i]}, inplace=True)

result.to_csv('Air/Selected/contri.csv')